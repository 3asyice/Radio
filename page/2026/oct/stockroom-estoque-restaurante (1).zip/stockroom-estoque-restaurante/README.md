# Stockroom — Estoque & Bar

Painel em HTML/CSS/JavaScript puro para estoque de restaurante, pensado para GitHub Pages e Supabase.

## O que já está incluído

- Produtos iniciais: refrigerantes, sucos, águas, queijos e salames.
- Cadastro, edição, pesquisa e remoção de produtos.
- Entradas, retiradas, cortes e ajustes de inventário com motivo e responsável.
- Registro de vendas do bar com baixa automática de estoque e totalização.
- Lotes e validade para produtos como queijos e salames.
- Alertas de estoque mínimo e validade em até 7 dias.
- Lista de compras sugerida e pedido semanal de queijos.
- Cadastro de fornecedores.
- Relatórios e exportação CSV/JSON; restauração de backup JSON.
- Layout responsivo com tema escuro inspirado em dashboards comerciais americanos.

## Arquivos

- `index.html`: aplicação.
- `supabase-schema.sql`: estrutura inicial do banco.

## Executar localmente

Abra `index.html` no navegador. Sem configuração do Supabase, o site funciona em modo local e guarda os dados no `localStorage` do navegador. **Esse modo não sincroniza entre dispositivos.**

## Publicar no GitHub Pages

1. Crie um repositório GitHub.
2. Envie `index.html` para a raiz do repositório.
3. Em **Settings → Pages**, escolha a branch principal e a pasta raiz.
4. Acesse a URL publicada.

## Banco compartilhado com Supabase

1. Crie um projeto Supabase.
2. Abra o **SQL Editor** e execute `supabase-schema.sql`.
3. Copie a Project URL e a chave pública (`publishable` ou `anon`, conforme o painel).
4. Abra a aplicação → **Configurações**, preencha URL e chave e salve.
5. Antes de usar com dados reais, implemente as políticas de acesso (RLS) apropriadas.

### Importante sobre segurança

O usuário pediu acesso sem login, mas um frontend público no GitHub Pages não consegue manter segredos. Uma chave pública do Supabase é normal no frontend; a proteção real depende de políticas RLS. **Não crie políticas que permitam livremente a qualquer visitante inserir, alterar ou apagar o estoque.** Para acesso sem contas individuais, use uma Edge Function/servidor que valide um PIN compartilhado no servidor e execute operações autorizadas, ou reveja a opção de autenticação. Nunca use `service_role` no HTML/JavaScript.

### Observações funcionais

- Os estoques iniciais começam em zero; cadastre as quantidades reais por meio de entradas.
- Os preços de venda vêm pré-preenchidos: latas R$ 8, sucos R$ 12, águas de 500 ml R$ 6.
- Queijos e salames são controlados inicialmente por kg; é possível alterar unidade.
- A lista automática usa como sugestão `2 × estoque mínimo − estoque atual`, e precisa ser revisada antes do pedido.
- Lotes e validade são registros separados; o sistema ainda não baixa automaticamente um lote específico ao registrar um corte.
- Os salames foram inicializados com os tipos Italiano, Tipo Hambúrguer e Copa. Adicione outros no cadastro.
- O sistema não é um PDV fiscal nem substitui controle sanitário formal.
