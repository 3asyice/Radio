-- Stockroom — estrutura inicial do Supabase
-- Execute no SQL Editor do seu projeto Supabase.
-- AVISO: não habilite escrita pública para anon sem proteção de servidor.
-- Estas tabelas usam UUIDs gerados pelo cliente para facilitar o protótipo.
create extension if not exists pgcrypto;

create table if not exists public.products (
  id text primary key,
  name text not null,
  category text not null,
  unit text not null default 'un',
  price numeric(12,2) not null default 0,
  stock numeric(14,3) not null default 0,
  "minStock" numeric(14,3) not null default 0,
  active boolean not null default true,
  "createdAt" timestamptz
);

create table if not exists public.movements (
  id text primary key,
  product_id text,
  product_name text,
  type text not null check (type in ('entrada','saida','ajuste')),
  quantity numeric(14,3) not null default 0,
  unit text,
  reason text,
  responsible text,
  note text,
  stock_before numeric(14,3),
  stock_after numeric(14,3),
  created_at timestamptz not null default now()
);

create table if not exists public.sales (
  id text primary key,
  items jsonb not null default '[]'::jsonb,
  total numeric(12,2) not null default 0,
  responsible text,
  note text,
  created_at timestamptz not null default now()
);

create table if not exists public.suppliers (
  id text primary key,
  name text not null,
  contact text,
  phone text,
  products text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.batches (
  id text primary key,
  product_id text,
  product_name text,
  lot text,
  quantity numeric(14,3) not null default 0,
  unit text,
  expiry date,
  opened_at date,
  created_at timestamptz not null default now()
);

alter table public.products enable row level security;
alter table public.movements enable row level security;
alter table public.sales enable row level security;
alter table public.suppliers enable row level security;
alter table public.batches enable row level security;

-- As políticas de RLS devem ser criadas de acordo com a forma de autenticação.
-- Para produção, prefira Supabase Auth ou uma Edge Function que valide um PIN
-- no servidor antes de executar gravações. Não publique service_role key no frontend.
